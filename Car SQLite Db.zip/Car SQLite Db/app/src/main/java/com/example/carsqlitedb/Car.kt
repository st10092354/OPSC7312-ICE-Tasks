package com.example.carsqlitedb

// data model class represents structure of data
data class Car(
    var id: Int = 0,
    var brand: String,
    var model: String,
    var year: Int
)
