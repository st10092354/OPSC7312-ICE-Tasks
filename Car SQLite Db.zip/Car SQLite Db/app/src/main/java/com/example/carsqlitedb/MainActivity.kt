package com.example.carsqlitedb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DbHelper
    private lateinit var etBrand: EditText
    private lateinit var etModel: EditText
    private lateinit var etYear: EditText
    private lateinit var listViewCars: ListView
    private lateinit var carAdapter: ArrayAdapter<String>
    private lateinit var carList: List<Car>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHelper = DbHelper(this)

        etBrand = findViewById(R.id.brandTV)
        etModel = findViewById(R.id.modelTV)
        etYear = findViewById(R.id.yearTV)
        listViewCars = findViewById(R.id.listViewCars)

        val btnAdd: Button = findViewById(R.id.buttonAdd)
        val btnUpdate: Button = findViewById(R.id.buttonUpdate)
        val btnDelete: Button = findViewById(R.id.buttonDelete)

        btnAdd.setOnClickListener{ addCar() }
        btnUpdate.setOnClickListener { updateCar() }
        btnDelete.setOnClickListener { deleteCar() }

        loadCars()

    }

    private fun addCar(){
        val brand = etBrand.text.toString()
        val model = etModel.text.toString()
        val year = etYear.text.toString().toInt()

        val car = Car(brand = brand, model = model, year = year)
        databaseHelper.addCar(car)
        loadCars()
    }

    private fun updateCar(){
        if (listViewCars.checkedItemPosition != ListView.INVALID_POSITION) {
            val car = carList[listViewCars.checkedItemPosition]
            car.brand = etBrand.text.toString()
            car.model = etModel.text.toString()
            car.year = etYear.text.toString().toInt()

            databaseHelper.updateCar(car)
            loadCars()
        } else {
            Toast.makeText(this, "Select a car to update", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteCar() {
        if (listViewCars.checkedItemPosition != ListView.INVALID_POSITION) {
            val car = carList[listViewCars.checkedItemPosition]
            databaseHelper.deleteCar(car)
            loadCars()
        } else {
            Toast.makeText(this, "Select a car to delete", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadCars(){
        carList = databaseHelper.getAllCars()
        val carNames = carList.map { "${it.brand} ${it.model} (${it.year})" }

        carAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, carNames)
        listViewCars.adapter = carAdapter
        listViewCars.choiceMode = ListView.CHOICE_MODE_SINGLE    }

}