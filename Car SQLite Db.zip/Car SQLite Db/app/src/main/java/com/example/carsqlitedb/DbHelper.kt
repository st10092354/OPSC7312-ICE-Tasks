package com.example.carsqlitedb

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// DbHelper extends SQLiteOpenHelper to manage db creation & version management
class DbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    // defining class members to be used independently of any instance of this class
    companion object{
        private const val DATABASE_NAME = "CarDB"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "Cars"
        private const val COLUMN_ID = "id"
        private const val COLUMN_BRAND = "brand"
        private const val COLUMN_MODEL = "model"
        private const val COLUMN_YEAR = "year"

    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = ("CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_BRAND TEXT," +
                "$COLUMN_MODEL TEXT," +
                "$COLUMN_YEAR INTEGER)")
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    // insert car into db
    fun addCar(car: Car): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues()

        contentValues.put(COLUMN_BRAND, car.brand)
        contentValues.put(COLUMN_MODEL, car.model)
        contentValues.put(COLUMN_YEAR, car.year)

        return db.insert(TABLE_NAME, null, contentValues)
    }

    //get all cars from db
    fun getAllCars(): List<Car> {
        val carList: ArrayList<Car> = ArrayList()
        val selectQuery = "SELECT * FROM $TABLE_NAME"
        val db = this.readableDatabase
        val cursor =db.rawQuery(selectQuery, null)

        if (cursor.moveToFirst()){
            do {
                val car = Car(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    brand = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BRAND)),
                    model = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MODEL)),
                    year = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_YEAR))
                )
                carList.add(car)
            }while (cursor.moveToNext())
        }

        cursor.close()
        return carList
    }

    // update can in db
    fun updateCar(car: Car): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()

        contentValues.put(COLUMN_BRAND, car.brand)
        contentValues.put(COLUMN_MODEL, car.model)
        contentValues.put(COLUMN_YEAR, car.year)

        return db.update(TABLE_NAME, contentValues, "$COLUMN_ID=?", arrayOf(car.id.toString()))
    }

    // delete car from db
    fun deleteCar(car: Car): Int {
        val db = this.writableDatabase
        return db.delete(TABLE_NAME, "$COLUMN_ID=?", arrayOf(car.id.toString()))
    }

}