package com.example.arrayadapter

class MyListAdapter {
}