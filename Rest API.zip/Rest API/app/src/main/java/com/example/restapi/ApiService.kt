package com.example.restapi

import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("items")
    fun getItems(): Call<List<Item>>

    @POST("items")
    fun addItem(@Body item: Item): Call<Item>

    @PUT("items/{id}")
    fun updateItem(@Path("id") id: String, @Body item: Item): Call<Item>

    @DELETE("items/{id}")
    fun deleteItem(@Path("id") id: String): Call<Void>
}

data class Item(
    val _id: String,
    val name: String,
    val description: String,
    val price: Double
)
