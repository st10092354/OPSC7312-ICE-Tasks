package com.example.restapi

import android.os.Build.VERSION_CODES.R
import android.os.Bundle
import android.telecom.Call
import android.view.WindowInsetsAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Response
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameEditText = findViewById<EditText>(R.id.editTextName)
        val descriptionEditText = findViewById<EditText>(R.id.editTextDescription)
        val priceEditText = findViewById<EditText>(R.id.editTextPrice)
        val resultTextView = findViewById<TextView>(R.id.textViewResult)

        val buttonAdd = findViewById<Button>(R.id.buttonAdd)
        val buttonGetAll = findViewById<Button>(R.id.buttonGetAll)

        apiService = RetrofitClient.instance.create(ApiService::class.java)

        // Add Item
        buttonAdd.setOnClickListener {
            val item = Item("", nameEditText.text.toString(), descriptionEditText.text.toString(), priceEditText.text.toString().toDouble())
            apiService.addItem(item).enqueue(object : WindowInsetsAnimation.Callback<Item> {
                override fun onResponse(call: Call<Item>, response: Response<Item>) {
                    resultTextView.text = "Item Added: ${response.body()}"
                }

                override fun onFailure(call: Call<Item>, t: Throwable) {
                    resultTextView.text = "Error: ${t.message}"
                }
            })
        }

        // Get All Items
        buttonGetAll.setOnClickListener {
            apiService.getItems().enqueue(object : WindowInsetsAnimation.Callback<List<Item>> {
                override fun onResponse(call: Call<List<Item>>, response: Response<List<Item>>) {
                    resultTextView.text = response.body().toString()
                }

                override fun onFailure(call: Call<List<Item>>, t: Throwable) {
                    resultTextView.text = "Error: ${t.message}"
                }
            })
        }
    }
}
