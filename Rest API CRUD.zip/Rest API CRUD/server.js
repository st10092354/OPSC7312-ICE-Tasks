const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

// Initialize the app
const app = express();
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb+srv://st10121157:Redburry@cluster0.4q2pj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', { useNewUrlParser: true, useUnifiedTopology: true });

// Define a schema and model
const ItemSchema = new mongoose.Schema({
    name: String,
    description: String,
    price: Number
});
const Item = mongoose.model('Item', ItemSchema);

// Create an item (Create)
app.post('/items', async (req, res) => {
    const item = new Item({
        name: req.body.name,
        description: req.body.description,
        price: req.body.price
    });
    await item.save();
    res.send(item);
});

// Read all items (Read)
app.get('/items', async (req, res) => {
    const items = await Item.find();
    res.send(items);
});

// Update an item (Update)
app.put('/items/:id', async (req, res) => {
    const item = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.send(item);
});

// Delete an item (Delete)
app.delete('/items/:id', async (req, res) => {
    await Item.findByIdAndDelete(req.params.id);
    res.send({ message: 'Item deleted' });
});

// Start the server
app.listen(3000, () => {
    console.log('Server running on port 3000');
});
